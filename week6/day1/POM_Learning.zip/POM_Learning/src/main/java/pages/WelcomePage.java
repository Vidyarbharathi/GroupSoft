package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecifcMethods;

public class WelcomePage extends ProjectSpecifcMethods{
	
	public WelcomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public WelcomePage verifyHomePage() {
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("WelcomePage is displayed");
		}
		else {
			System.out.println("WelcomePage is not displayed");
		}
		return this;
	}
	
	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage(driver);

	}

}
