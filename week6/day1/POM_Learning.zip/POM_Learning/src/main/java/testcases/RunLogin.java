package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecifcMethods;
import pages.LoginPage;

public class RunLogin extends ProjectSpecifcMethods{
	
	@Test
	public void runLogin() {
		/*
		 * System.out.println("Test Method: "+driver); LoginPage lp = new LoginPage();
		 * lp.enterUsername(); lp.enterPassword(); lp.clickLoginButton();
		 * 
		 * WelcomePage wp = new WelcomePage(); wp.verifyHomePage();
		 */
		System.out.println(driver);
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.verifyHomePage();


	}

}
