package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecifcMethods;
import config.Configuration;

public class MyLeadsPage extends ProjectSpecifcMethods{
	
	public MyLeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage clickCreateLeadLink() {
		driver.findElement(By.partialLinkText(Configuration.configuration().getCreateLeadLink())).click();
		return new CreateLeadPage(driver);

	}

}
