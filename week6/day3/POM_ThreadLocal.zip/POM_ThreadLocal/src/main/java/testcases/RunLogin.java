package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecifcMethods;
import pages.LoginPage;

public class RunLogin extends ProjectSpecifcMethods{

	@BeforeTest
	public void setValues() {
		fileName="Login";

	}

	@Test(dataProvider = "fetchData")
	public void runLogin(String uName, String pWord) {

		LoginPage lp = new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyHomePage();


	}

}
