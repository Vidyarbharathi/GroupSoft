package pages;

import org.openqa.selenium.By;

import base.ProjectSpecifcMethods;

public class MyHomePage extends ProjectSpecifcMethods{
	
	public MyLeadsPage clickLeadsLink() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new MyLeadsPage();

	}

}
