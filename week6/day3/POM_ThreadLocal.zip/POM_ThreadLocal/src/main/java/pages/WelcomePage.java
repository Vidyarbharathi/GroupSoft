package pages;

import org.openqa.selenium.By;

import base.ProjectSpecifcMethods;

public class WelcomePage extends ProjectSpecifcMethods{
	
	public WelcomePage verifyHomePage() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("WelcomePage is displayed");
		}
		else {
			System.out.println("WelcomePage is not displayed");
		}
		return this;
	}
	
	public MyHomePage clickCRMSFALink() {
		getDriver().findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage();

	}

}
