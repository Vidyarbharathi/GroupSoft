package pages;

import org.openqa.selenium.By;

import base.ProjectSpecifcMethods;

public class MyLeadsPage extends ProjectSpecifcMethods{
	
	
	public CreateLeadPage clickCreateLeadLink() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();

	}

}
