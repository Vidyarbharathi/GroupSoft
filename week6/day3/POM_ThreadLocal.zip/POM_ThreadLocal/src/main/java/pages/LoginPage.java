package pages;

import org.openqa.selenium.By;

import base.ProjectSpecifcMethods;

public class LoginPage extends ProjectSpecifcMethods{


	public LoginPage enterUsername(String uName) {

		try {
			getDriver().findElement(By.id("username123")).sendKeys(uName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException("View the logs for more details"); 
		}

		return this;

	}

	public LoginPage enterPassword(String pWord) {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pWord);
		} catch (Exception e) {
			System.out.println(e);
		}
		return this;

	}

	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();	
		return new WelcomePage();

	}

}
