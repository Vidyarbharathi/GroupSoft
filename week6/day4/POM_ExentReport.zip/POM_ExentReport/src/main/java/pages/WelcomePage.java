package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods{
	
	public WelcomePage verifyLogin() {
		
		String text = getDriver().findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("Logged in Successfully");
		}
		else {
			System.out.println("Login is not successfull");
		}
		
		return this;

	}

	public MyHomePage clickCRMSFALink() {
		getDriver().findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage();
	}

}
