package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage enterUsername(String uName) throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(uName);
			reportStep(uName + " is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(uName + "is not entered successfully " +e, "fail");
		}
		return this;

	}

	public LoginPage enterPassword(String pWord) throws IOException {
		
		try {
			getDriver().findElement(By.id("password")).sendKeys(pWord);
			reportStep(pWord+" is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(pWord+ " is not entered successfully" +e, "fail");
		}
		return this;
		

	}

	public WelcomePage clickLoginButton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked successfully" +e, "fail");
		}
		return new WelcomePage();

	}

}
